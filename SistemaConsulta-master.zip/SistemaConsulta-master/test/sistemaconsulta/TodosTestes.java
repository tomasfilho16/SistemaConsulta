/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaconsulta;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 *
 * @author andrio
 */
@RunWith(Suite.class)
@SuiteClasses({GerenciaPacientesTest_Ex1.class, GerenciaPacientesTest_Ex6.class})
public class TodosTestes {
    
 

}
